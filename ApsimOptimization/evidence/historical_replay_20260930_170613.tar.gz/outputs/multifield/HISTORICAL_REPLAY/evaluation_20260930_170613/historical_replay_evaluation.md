# Historical N replay evaluation

Acceptance status: `no_validation_accuracy_gain_mechanistic_calibration_required`

The control uses the original static field fertilizer managers. The replay changes only the N amount on sowing events that have an explicit N rate and sowing date in the supplied observation file. APSIM fertilizer type is preserved.

| Scope | n | Control MAE | Replay MAE | Change | Control RMSE | Replay RMSE | Change |
|---|---:|---:|---:|---:|---:|---:|---:|
| Calibration 2019-2022 | 27 | 1.437 | 1.477 | +0.040 | 1.933 | 1.943 | +0.010 |
| Validation 2023 | 10 | 1.216 | 1.357 | +0.141 | 1.481 | 1.675 | +0.195 |
| All observations | 37 | 1.377 | 1.445 | +0.068 | 1.821 | 1.874 | +0.053 |

## Decision-readiness gate

Selected historical case: `control`

Status: `historical_validation_not_ready_for_decision_optimization`

| Check | Result |
|---|---|
| complete_validation_coverage | PASS |
| all_validation_harvest_events_present | PASS |
| validation_rmse_better_than_training_mean | FAIL |
| positive_validation_field_ranking | FAIL |

Validation RMSE: `1.481 t/ha`; training-mean RMSE: `0.837 t/ha`; Spearman field rank: `-0.297`.

No absolute agronomic error threshold was assumed. Readiness requires complete held-out coverage, harvest events, lower RMSE than the calibration-period mean, and positive Spearman field ranking.

## Largest field effects

| Year/field | Crop | Observed N | Control N | Replay N | Yield change, t/ha |
|---|---|---:|---:|---:|---:|
| 2022/Field4 | Овёс | 30 | 10 | 30 | +1.197 |
| 2021/Field6 | Овёс | 60 | 30 | 60 | +1.096 |
| 2022/Field7 | Яровая пшеница | 60 | 30 | 60 | +0.789 |
| 2023/Field9 | Озимая рожь | 60 | 30 | 60 | +0.679 |
| 2022/Field8 | Озимая рожь | 60 | 30 | 60 | +0.633 |
| 2023/Field7 | Овёс | 60 | 30 | 60 | +0.571 |
| 2023/Field8 | Яровая пшеница | 60 | 30 | 60 | +0.542 |
| 2021/Field4 | Яровая пшеница | 30 | 10 | 30 | +0.040 |
| 2021/Field1 | Овёс | 30 | 10 | 30 | +0.009 |
| 2019/Field3 | Овёс | 30 | 30 | 30 | +0.000 |
| 2019/Field7 | Яровая пшеница | 30 | 30 | 30 | +0.000 |
| 2020/Field2 | Озимая рожь | 30 | 30 | 30 | +0.000 |

P/K labels remain diagnostic flags because the APSIM model has no responsive P/K pools. The result cannot establish fertilizer dose bounds, nutrient target intervals, products, prices, or ratios.

Control checkpoint: `outputs/multifield/quality_history/checkpoints/20260930T140705Z_historical_static_control_20260930_170613_74aaee9d`

Replay checkpoint: `outputs/multifield/quality_history/checkpoints/20260930T140756Z_historical_n_replay_20260930_170613_74aaee9d`
